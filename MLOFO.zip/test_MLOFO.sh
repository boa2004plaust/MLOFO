#!/bin/bash
# Build documentation for display in web browser.

python test_MLOFO.py --d 'CUB' --model-dir 'CUB_resnet50_mlofo_epochs200_lr0.0035_warmup5_distcos_sample4_weight0.001_log'


